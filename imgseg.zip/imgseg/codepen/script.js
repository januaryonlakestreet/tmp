//blatantly copying chassis from https://codepen.io/bbo-underhill/pen/YzqwyEB


const draw = () => {
  tf.setBackend("webgl");
  tf.ready().then(async () => {
    const model = bodySegmentation.SupportedModels.BodyPix;
    const segmenterConfig = {
      runtime: "tfjs",
    };
    const segmenter = await bodySegmentation.createSegmenter(
      model,
      segmenterConfig
    );
    let webcamImage;
    webcamImage = await createImageBitmap(document.getElementById("webcam"));
    const segmentationConfig = { flipHorizontal: false };
    const tfSegmentation = await segmenter.segmentPeople(
      webcamImage,
      segmentationConfig
    );
    const mask = tfSegmentation[0].mask;
console.log(mask);
    const output = await createImageBitmap(await mask.toImageData());
    const canvas = document.getElementById("canvas");
    const ctx = canvas.getContext("2d");
    ctx.drawImage(output, 0, 0);
  });
};

const video = document.getElementById("webcam");

function hasGetUserMedia() {
  return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
}
// Enable the live webcam view and start classification.
function enableCam(event) {
  // getUsermedia parameters.
  const constraints = {
    video: true,
  };

  // Activate the webcam stream.
  navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
    video.srcObject = stream;
    video.addEventListener("loadeddata", predictWebcam);
    video.style.display = "none";
  });
}

// If webcam supported, add event listener to button for when user
// wants to activate it.
if (hasGetUserMedia()) {
  const enableWebcamButton = document.getElementById("webcamButton");
  enableWebcamButton.addEventListener("click", enableCam);
  const drawButton = document.getElementById("drawButton");
  drawButton.addEventListener("click", draw);
} else {
  console.warn("getUserMedia() is not supported by your browser");
}
